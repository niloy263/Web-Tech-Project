<h1 align="center">Admin panel</h1>

<head>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="design.css">
</head>

<body>
    <div class="menubar">
        <a href="admin.php">Home</a>

        <div class="menubar_content">
            <a href="#">My personal Information</a>
            <div class="menubar_subcontent">
                <a href="adminAboutMe.php">My details</a>
                <a href="adminChangePassword.php">Change my password</a>
            </div>
        </div>

        <div class="menubar_content2">
            <a href="#">Other user information</a>
            <div class="menubar_subcontent2">
                <a href="adminShowAllUser.php">Show all user</a>
                <a href="adminEditUser.php">Edit any user</a>
                <a href="adminDeleteAccount.php">Delete any user</a>
            </div>
        </div>

        <div class="menubar_content3">
            <a href="#">All car information</a>
            <div class="menubar_subcontent3">
                <a href="showAllCar.php">Show all car</a>
                <a href="addCar.php">Add car</a>
                <a href="editCar.php">Edit any car</a>
                <a href="deleteCar.php">Delete any car</a>
            </div>
        </div>

        <a href="login.php">Logout</a>
    </div>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>






<?php include '../Controller/changePasswordC.php'; ?>

<table align="center">
    <tr>
        <th><img src="adminkey.png" alt="" height=200 width=200 /></th>
    </tr>
    <tr>
        <td>
            <br>
            <h3><u>Change Admin Password:</u></h3><br>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">
                Enter new password:
                <div class="form-control">
                    <input class="form-control" type="password" name="name_pass">
                </div>
                <input class="buttonMain" style="display:block; margin: 0 auto;" type="submit" name="dpchange" value="Change password">
            </form>
        </td>

        <br>

    </tr>
</table>