<h1 align="center">Owner Page</h1>

<head>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="ownerdesign.css">
</head>

<body>
    <div class="menubar">
        <a href="owner.php">Home</a>

        <div class="menubar_content">
            <a href="#">My personal Information</a>
            <div class="menubar_subcontent">
                <a href="ownerAboutMe.php">My details</a>
                <a href="ownerChangePassword.php">Change my password</a>
            </div>
        </div>

        <div class="menubar_content2">
            <a href="#">Other user information</a>
            <div class="menubar_subcontent2">
                <a href="ownerShowAllCustomer.php">Show all customer</a>
                <a href="ownerShowAllDriver.php">Show all driver</a>
                <a href="ownerShowAllOnwer.php">Show all owner</a>
            </div>
        </div>

        <div class="menubar_content3">
            <a href="#">All car information</a>
            <div class="menubar_subcontent3">
                <a href="ownerShowAllCar.php">Show all car</a>
                <a href="ownerAddCar.php">Add car</a>
                <a href="ownerEditCar.php">Edit any car</a>
            </div>
        </div>

        <a href="login.php">Logout</a>
    </div>
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
</body>



<?Php
session_start();
echo "<h3 align='right' style='color:green;'>login as (" . $_SESSION['user'] . ") </h3>";
?>
<table align="center">
<td>
            <img src="4owner.PNG" alt="" height=300 width=300 />
        </td><br>
</table>

<table align="center">
    <tr>
        <th></th>
    </tr>
    <tr>
        <td>
            <?php
            $count = 0;
            $driver_count = 1;

            $current_data = file_get_contents('../Model/userdata.json');
            $array_data = json_decode($current_data, false);

            foreach ($array_data as $b) {
                if ($b->role == "Driver") {
                    echo '<b>Driver No. </b>' . $driver_count . "," . "<br>";
                    echo "Username: " . $b->name . "<br>";
                    echo "Gender : " . $b->gender . "<br>";
                    echo "Role : " .  $b->role . "<br>";
                    echo "I have : " . $b->have . "<br>";
                    echo "Address : " . $b->address . "<br>";
                    "<br>";
                    "<br>";
                    $driver_count += 1;
                    $count += 1;
                } else {
                    $count += 1;
                }
            }
            ?>

        </td>
    </tr>
</table>